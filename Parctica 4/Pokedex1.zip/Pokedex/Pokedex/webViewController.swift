//
//  webViewController.swift
//  Pokedex
//
//  Created by g834 DIT UPM on 31/10/18.
//  Copyright © 2018 g834. All rights reserved.
//

import UIKit

class webViewController: UIViewController {
    
    // Race a mostrar, o nil para mostrar la pagina Home
    var race: Race?

    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

       // URL a mostrar
        var str = "https://es.pokemon.wikia.com"
        
        if race != nil {
            
            // Poner nombre de la raza como titulo de la Navigation Bar
            title = race!.name
            
            // Añadir la raza al URL escapando caracteres conflictivos
            if let path = "wiki/\(race!.name)".addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) {
                
                str = "\(str)/\(path)"
            }
        }else{
            
            // Poner Pokedex como titulo de la Navigation Bar
            title = "Pokedex"
        }
        
        if let url = URL(string: str) {
            let req = URLRequest(url: url)
            webView.loadRequest(req)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

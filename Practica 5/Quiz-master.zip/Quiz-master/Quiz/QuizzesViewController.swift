//
//  QuizzesViewController.swift
//  Quiz
//
//  Created by g807 DIT UPM on 15/11/18.
//  Copyright © 2018 g807 DIT UPM. All rights reserved.
//

import UIKit

class QuizzesViewController: UIViewController {
    
    var question: String!
    var image: UIImage!

    @IBOutlet weak var QuestionLabel: UILabel!
    
    @IBOutlet weak var AnswerSpaceLabel: UITextField!
    
    @IBOutlet weak var ImageLabel: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Responda: "
        QuestionLabel.text = "\(question!)"
        ImageLabel.image = image
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pushComprobar(_ sender: UIButton) {
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

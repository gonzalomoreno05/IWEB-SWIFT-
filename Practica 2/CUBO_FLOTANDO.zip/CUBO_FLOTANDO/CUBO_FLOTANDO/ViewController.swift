//
//  ViewController.swift
//  CUBO_FLOTANDO
//
//  Created by g834 DIT UPM on 2/10/18.
//  Copyright © 2018 g834. All rights reserved.
//

import UIKit

class ViewController: UIViewController, FunctionViewDataSource {
    
    
    @IBOutlet weak var TituloLabel: UILabel!
    @IBAction func manejaTap(_ sender: UITapGestureRecognizer) {
        if TituloLabel.textColor == UIColor.black {
            
        TituloLabel.textColor = UIColor.red
        }
        else if TituloLabel.textColor == UIColor.red {
            TituloLabel.textColor = UIColor.blue
        }
        else if TituloLabel.textColor == UIColor.blue{
            TituloLabel.textColor = UIColor.green
        }
        else if TituloLabel.textColor == UIColor.green {
            TituloLabel.textColor = UIColor.white
        }
        else {
            TituloLabel.textColor = UIColor.black
        }
    }
       @IBAction func manejaPinch(_ sender: UIPinchGestureRecognizer) {
        cubo.lado *= Double(sender.scale)
       
        
        posicionView.setNeedsDisplay()
        velocidadView.setNeedsDisplay()
        aceleracionView.setNeedsDisplay()
        ZLabel.text = String(round(cubo.zPos*100)/100) + " m"
        VelLabel.text = String(round(cubo.vel*100)/100) + " m/seg"
        AcLabel.text = String(round(cubo.acc*100)/100) + " m/seg2"
        posVelView.setNeedsDisplay()
        
         sender.scale = 1
    }
    
    @IBOutlet weak var ladoSlider: UISlider!
    @IBOutlet weak var tiempoSlider: UISlider!
    
    @IBOutlet weak var posicionView: FunctionView!
    @IBOutlet weak var velocidadView: FunctionView!
    @IBOutlet weak var aceleracionView: FunctionView!
    @IBOutlet weak var posVelView: FunctionView!
    @IBOutlet weak var ZLabel: UILabel!
    @IBOutlet weak var VelLabel: UILabel!
    @IBOutlet weak var AcLabel: UILabel!
    
    var cubo: Cubo_flotando!
    
    // Instante en el que quiero dibujar la trayectoria del agua desde el
    var trajectoryTime: Double = 0.0 {
        didSet {
            posicionView.setNeedsDisplay()
            velocidadView.setNeedsDisplay()
            aceleracionView.setNeedsDisplay()
            posVelView.setNeedsDisplay()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cubo = Cubo_flotando()
        
        posicionView.dataSource = self
        velocidadView.dataSource = self
        aceleracionView.dataSource = self
        posVelView.dataSource = self
        
        posicionView.scaleX = 20.0
        posicionView.scaleY = 15.0
        
        velocidadView.scaleX = 20.0
        velocidadView.scaleY = 7.0
        
        aceleracionView.scaleX = 20.0
        aceleracionView.scaleY = 3.0
        
        posVelView.scaleX = 35.0
        posVelView.scaleY = 15.0
        
        ladoSlider.sendActions(for: .valueChanged)
        tiempoSlider.sendActions(for: .valueChanged)
        
        
    }
    
    
    @IBAction func ladoChanged(_ sender: UISlider) {
        cubo.lado = Double(sender.value)
        
        posicionView.setNeedsDisplay()
        velocidadView.setNeedsDisplay()
        aceleracionView.setNeedsDisplay()
        ZLabel.text = String(round(cubo.zPos*100)/100) + " m"
        VelLabel.text = String(round(cubo.vel*100)/100) + " m/seg"
        AcLabel.text = String(round(cubo.acc*100)/100) + " m/seg2"
        posVelView.setNeedsDisplay()
    }
    
    @IBAction func tiempoChanged(_ sender: UISlider) {
        trajectoryTime = Double(sender.value)
    }
    
    func startTimeOfFunctionView(_ functionView: FunctionView) -> Double {
        return 0
    }
    
    
    func endTimeOfFunctionView(_ functionView: FunctionView) -> Double {
        return 20
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func pointOfFunctionView(_ functionView: FunctionView, atTime time: Double) -> Point {
        switch functionView {
            
        case posicionView:
            let x = time
            let y = cubo.zAt(time: time)
            return Point(x:x, y:y)
            
        case velocidadView:
            let x = time
            let y = cubo.vAt(time: time)
            return Point(x:x, y:y)
            
        case aceleracionView:
            let x = time
            let y = cubo.aAt(time: time)
            return Point(x:x, y:y)
            
        case posVelView:
            let x = cubo.zAt(time: time)
            let y = cubo.vAt(time: time)
            return Point(x:x, y:y)
            
        default:
            return Point(x:0, y:0)
        }
        
    }
    
    func pointsOfInterestFor(_ functionView: FunctionView) -> [Point] {
        switch functionView {
        case posicionView:
            
            // Velocidad de salida del agua en el instante actual
            let x = trajectoryTime
            let y = cubo.zAt(time: x)
            return [ Point(x: x, y: y) ]
            
        case velocidadView:
            
            // Velocidad de salida del agua en funcion de la altura de agua en el deposito
            let x = trajectoryTime
            let y = cubo.vAt(time: x)
            return [ Point(x: x, y: y) ]
            
        case aceleracionView:
            
            // Altura de agua en el deposito en el instante actual
            let x = trajectoryTime
            let y = cubo.aAt(time: x)
            return [Point(x: x, y: y)]
            
        case posVelView:
            let x = cubo.zAt(time: trajectoryTime)
            let y = cubo.vAt(time: trajectoryTime)
            return [Point(x:x, y:y)]
            
        default:
            return []
            
        }
    }
    
    

}


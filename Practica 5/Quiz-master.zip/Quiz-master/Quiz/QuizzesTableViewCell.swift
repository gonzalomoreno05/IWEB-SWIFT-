//
//  QuizzesTableViewCell.swift
//  Quiz
//
//  Created by g807 DIT UPM on 15/11/18.
//  Copyright © 2018 g807 DIT UPM. All rights reserved.
//

import UIKit

class QuizzesTableViewCell: UITableViewCell {

    @IBOutlet weak var imageLabel: UIImageView!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var questionLabel: UILabel!
    
}

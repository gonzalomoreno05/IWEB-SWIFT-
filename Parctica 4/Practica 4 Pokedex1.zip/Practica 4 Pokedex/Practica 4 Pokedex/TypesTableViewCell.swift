//
//  TypesTableViewCell.swift
//  Practica 4 Pokedex
//
//  Created by g834 DIT UPM on 5/11/18.
//  Copyright © 2018 g834 DIT UPM. All rights reserved.
//

import UIKit

class TypesTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var counterLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    

}

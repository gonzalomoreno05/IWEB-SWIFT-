//
//  Cubo_flotando.swift
//  Practica2
//
//  Created by g834 DIT UPM on 1/10/18.
//  Copyright © 2018 g834. All rights reserved.
//

import Foundation

class Cubo_flotando{


    static let g = 9.8 //m/seg2
    
    var lado = 0.3{  //lado del cubo 30 cm
        didSet {
            actualizaVelAng()
        }
    }
    
    private var w: Double = 0.0 //velocidad angular
    var zPos: Double = 0
    var vel: Double = 0
    var acc: Double = 0
    
    //metodos
    
    
    init() { //inicializador
        actualizaVelAng()
    }
    
    private func actualizaVelAng(){     //actualiza la velocidad angular dependiendo del lado
        return w = sqrt(2*Cubo_flotando.g/lado)
    }
    
    func zAt(time t: Double) -> Double{     //posicion del cubo en funcion del tiempo
        zPos = (1/2)*lado*cos(w*t)
        return zPos
    }
  
    func vAt(time t: Double) -> Double{     //velocidad del cubo en funcion del tiempo
        vel = (-1/2)*lado*w*sin(w*t)
        return vel
    }
    
    func aAt(time t: Double) -> Double{     //aceleracion del cubo en funcion del tiempo
        acc = Cubo_flotando.g*cos(w*t)
        return acc    }
    
}
